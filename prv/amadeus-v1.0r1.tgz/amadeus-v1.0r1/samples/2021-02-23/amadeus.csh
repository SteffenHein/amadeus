#!/bin/csh
set init=1
set final=15

set LOG_FILE="par.log"
set INIT_FILE="par.init"
# now iterate

@ i = ${init}
while ( $i <= ${final} )
	if (-f ./${INIT_FILE}$i) then
		echo "calling amadeus ""$i"
		amadeus -n $i -f ${INIT_FILE}$i
#		cp ${LOG_FILE}$i ${INIT_FILE}$i
	endif
	@ i ++
end
#
echo "Done"
